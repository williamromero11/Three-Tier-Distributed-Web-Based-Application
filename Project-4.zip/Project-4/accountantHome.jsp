<!DOCTYPE html>
<html>
<head>
    <title>Accountant Interface</title>
</head>
<body>

<h1>Accountant Interface</h1>

<form action="AccountantServlet" method="post">
    <button name="action" value="maxStatus">Get Maximum Supplier Status</button>
</form>

<form action="AccountantServlet" method="post">
    <button name="action" value="totalWeight">Get Total Weight of Parts</button>
</form>

<form action="AccountantServlet" method="post">
    <button name="action" value="totalShipments">Get Total Shipments</button>
</form>

<form action="AccountantServlet" method="post">
    <button name="action" value="maxWorkers">Get Job with Most Workers</button>
</form>

<form action="AccountantServlet" method="post">
    <button name="action" value="supplierList">Get Supplier Names and Status</button>
</form>

<hr>

<%
    String result = (String) request.getAttribute("result");
    if (result != null) {
%>
    <h3><%= result %></h3>
<%
    }
%>

</body>
</html>