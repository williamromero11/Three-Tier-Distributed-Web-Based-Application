<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Entry Interface</title>
</head>
<body>
    <h1>Data Entry Interface</h1>

    <hr>

    <h2>Add Supplier</h2>
    <form action="DataEntryServlet" method="post">
        <input type="hidden" name="action" value="insertSupplier">

        <label>Supplier Number:</label>
        <input type="text" name="snum" required><br><br>

        <label>Supplier Name:</label>
        <input type="text" name="sname" required><br><br>

        <label>Status:</label>
        <input type="number" name="status" required><br><br>

        <label>City:</label>
        <input type="text" name="city" required><br><br>

        <input type="submit" value="Insert Supplier">
    </form>

    <hr>

    <h2>Add Part</h2>
    <form action="DataEntryServlet" method="post">
        <input type="hidden" name="action" value="insertPart">

        <label>Part Number:</label>
        <input type="text" name="pnum" required><br><br>

        <label>Part Name:</label>
        <input type="text" name="pname" required><br><br>

        <label>Color:</label>
        <input type="text" name="color" required><br><br>

        <label>Weight:</label>
        <input type="number" name="weight" required><br><br>

        <label>City:</label>
        <input type="text" name="city" required><br><br>

        <input type="submit" value="Insert Part">
    </form>

    <hr>

    <h2>Add Job</h2>
    <form action="DataEntryServlet" method="post">
        <input type="hidden" name="action" value="insertJob">

        <label>Job Number:</label>
        <input type="text" name="jnum" required><br><br>

        <label>Job Name:</label>
        <input type="text" name="jname" required><br><br>

        <label>Number of Workers:</label>
        <input type="number" name="numworkers" required><br><br>

        <label>City:</label>
        <input type="text" name="city" required><br><br>

        <input type="submit" value="Insert Job">
    </form>

    <hr>

    <h2>Add Shipment</h2>
    <form action="DataEntryServlet" method="post">
        <input type="hidden" name="action" value="insertShipment">

        <label>Supplier Number:</label>
        <input type="text" name="shipment_snum" required><br><br>

        <label>Part Number:</label>
        <input type="text" name="shipment_pnum" required><br><br>

        <label>Job Number:</label>
        <input type="text" name="shipment_jnum" required><br><br>

        <label>Quantity:</label>
        <input type="number" name="quantity" required><br><br>

        <input type="submit" value="Insert Shipment">
    </form>

    <hr>

    <h2>Execution Results:</h2>
    <%
        Object resultObj = request.getAttribute("result");
        if (resultObj != null) {
    %>
        <div>
            <%= resultObj %>
        </div>
    <%
        }
    %>
</body>
</html>