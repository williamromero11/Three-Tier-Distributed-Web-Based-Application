<!DOCTYPE html>
<html>
<head>
    <title>Client Interface</title>
</head>
<body>

<h1>Client SQL Interface</h1>

<form method="post" action="ClientServlet">
    <textarea name="sqlCommand" rows="6" cols="60"></textarea><br><br>

    <input type="submit" value="Execute Command">
    <input type="reset" value="Reset">
</form>

<hr>

<%
    if (request.getAttribute("result") != null) {
        out.println(request.getAttribute("result"));
    }
%>

</body>
</html>