import java.io.*;
import java.sql.*;
import java.util.Properties;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class AccountantServlet extends HttpServlet {

    private Properties loadProperties(String fileName, ServletContext context) throws IOException {
        Properties props = new Properties();
        String path = context.getRealPath("/WEB-INF/conf/" + fileName);

        try (FileInputStream fis = new FileInputStream(path)) {
            props.load(fis);
        }

        return props;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        StringBuilder result = new StringBuilder();

        Connection conn = null;
        CallableStatement cs = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Properties props = loadProperties("accountant.properties", getServletContext());

            conn = DriverManager.getConnection(
                props.getProperty("db.url"),
                props.getProperty("db.username"),
                props.getProperty("db.password")
            );

            if ("maxStatus".equals(action)) {
                cs = conn.prepareCall("{CALL Get_The_Maximum_Status_Of_All_Suppliers()}");
                rs = cs.executeQuery();
                while (rs.next()) {
                    result.append("Max Supplier Status: ").append(rs.getInt(1));
                }

            } else if ("totalWeight".equals(action)) {
                cs = conn.prepareCall("{CALL Get_The_Sum_Of_All_Parts_Weights()}");
                rs = cs.executeQuery();
                while (rs.next()) {
                    result.append("Total Weight: ").append(rs.getInt(1));
                }

            } else if ("totalShipments".equals(action)) {
                cs = conn.prepareCall("{CALL Get_The_Total_Number_Of_Shipments()}");
                rs = cs.executeQuery();
                while (rs.next()) {
                    result.append("Total Shipments: ").append(rs.getInt(1));
                }

            } else if ("maxWorkers".equals(action)) {
                cs = conn.prepareCall("{CALL Get_The_Name_Of_The_Job_With_The_Most_Workers()}");
                rs = cs.executeQuery();
                while (rs.next()) {
                    result.append("Job with Most Workers: ")
                          .append(rs.getString(1))
                          .append(" (")
                          .append(rs.getInt(2))
                          .append(" workers)");
                }

            } else if ("supplierList".equals(action)) {
                cs = conn.prepareCall("{CALL List_The_Name_And_Status_Of_All_Suppliers()}");
                rs = cs.executeQuery();

                result.append("<table border='1'>");
                result.append("<tr><th>Name</th><th>Status</th></tr>");

                while (rs.next()) {
                    result.append("<tr><td>")
                          .append(rs.getString(1))
                          .append("</td><td>")
                          .append(rs.getInt(2))
                          .append("</td></tr>");
                }

                result.append("</table>");
            }

        } catch (Exception e) {
            result.append("Error: ").append(e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (cs != null) cs.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        request.setAttribute("result", result.toString());
        request.getRequestDispatcher("accountantHome.jsp").forward(request, response);
    }
}