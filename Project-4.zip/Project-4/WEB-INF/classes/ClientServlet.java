import java.io.*;
import java.sql.*;
import java.util.Properties;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ClientServlet extends HttpServlet {

    private Properties loadProperties(String fileName, ServletContext context) throws IOException {
        Properties props = new Properties();
        String path = context.getRealPath("/WEB-INF/conf/" + fileName);

        try (FileInputStream fis = new FileInputStream(path)) {
            props.load(fis);
        }

        return props;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String sqlCommand = request.getParameter("sqlCommand");
        StringBuilder result = new StringBuilder();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Properties props = loadProperties("client.properties", getServletContext());

            Connection conn = DriverManager.getConnection(
                props.getProperty("db.url"),
                props.getProperty("db.username"),
                props.getProperty("db.password")
            );

            Statement stmt = conn.createStatement();

            boolean hasResult = stmt.execute(sqlCommand);

            if (hasResult) {
                ResultSet rs = stmt.getResultSet();
                ResultSetMetaData meta = rs.getMetaData();
                int cols = meta.getColumnCount();

                result.append("<table border='1'>");

                result.append("<tr>");
                for (int i = 1; i <= cols; i++) {
                    result.append("<th>").append(meta.getColumnName(i)).append("</th>");
                }
                result.append("</tr>");

                while (rs.next()) {
                    result.append("<tr>");
                    for (int i = 1; i <= cols; i++) {
                        result.append("<td>").append(rs.getString(i)).append("</td>");
                    }
                    result.append("</tr>");
                }

                result.append("</table>");

            } else {
                int count = stmt.getUpdateCount();
                result.append("Command executed successfully. Rows affected: ").append(count);
            }

            conn.close();

        } catch (Exception e) {
            result.append("Error: ").append(e.getMessage());
        }

        request.setAttribute("result", result.toString());
        request.getRequestDispatcher("clientHome.jsp").forward(request, response);
    }
}