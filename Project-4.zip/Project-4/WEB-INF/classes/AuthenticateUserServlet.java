import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuthenticateUserServlet extends HttpServlet {

    private Properties loadProperties(String fileName) throws IOException {
        Properties props = new Properties();
        String fullPath = getServletContext().getRealPath("/WEB-INF/conf/" + fileName);

        try (FileInputStream fis = new FileInputStream(fullPath)) {
            props.load(fis);
        }

        return props;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Properties props = loadProperties("systemapp.properties");

            String dbUrl = props.getProperty("db.url");
            String dbUser = props.getProperty("db.username");
            String dbPass = props.getProperty("db.password");

            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                 PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM usercredentials WHERE login_username = ? AND login_password = ?")) {

                ps.setString(1, username);
                ps.setString(2, password);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        if ("root".equals(username)) {
                            response.sendRedirect("rootHome.jsp");
                        } else if ("client".equals(username)) {
                            response.sendRedirect("clientHome.jsp");
                        } else if ("dataentry".equals(username)) {
                            response.sendRedirect("dataEntryHome.jsp");
                        } else if ("theaccountant".equals(username)) {
                            response.sendRedirect("accountantHome.jsp");
                        } else {
                            response.sendRedirect("errorpage.html");
                        }
                    } else {
                        response.sendRedirect("errorpage.html");
                    }
                }
            }

        } catch (Exception e) {
            throw new ServletException("Authentication error: " + e.getMessage(), e);
        }
    }
}