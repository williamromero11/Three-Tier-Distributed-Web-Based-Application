import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DataEntryServlet extends HttpServlet {

    private Properties loadProperties(ServletContext context) throws IOException {
        Properties props = new Properties();
        String path = context.getRealPath("/WEB-INF/conf/dataentry.properties");

        try (FileInputStream fis = new FileInputStream(path)) {
            props.load(fis);
        }

        return props;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String result = "";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Properties props = loadProperties(getServletContext());

            conn = DriverManager.getConnection(
                props.getProperty("db.url"),
                props.getProperty("db.username"),
                props.getProperty("db.password")
            );

            if ("insertSupplier".equals(action)) {
                String snum = request.getParameter("snum");
                String sname = request.getParameter("sname");
                int status = Integer.parseInt(request.getParameter("status"));
                String city = request.getParameter("city");

                String sql = "insert into suppliers (snum, sname, status, city) values (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, snum);
                pstmt.setString(2, sname);
                pstmt.setInt(3, status);
                pstmt.setString(4, city);

                int rows = pstmt.executeUpdate();
                result = "Supplier inserted successfully. " + rows + " row(s) affected.";
            }
            else if ("insertPart".equals(action)) {
                String pnum = request.getParameter("pnum");
                String pname = request.getParameter("pname");
                String color = request.getParameter("color");
                int weight = Integer.parseInt(request.getParameter("weight"));
                String city = request.getParameter("city");

                String sql = "insert into parts (pnum, pname, color, weight, city) values (?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, pnum);
                pstmt.setString(2, pname);
                pstmt.setString(3, color);
                pstmt.setInt(4, weight);
                pstmt.setString(5, city);

                int rows = pstmt.executeUpdate();
                result = "Part inserted successfully. " + rows + " row(s) affected.";
            }
            else if ("insertJob".equals(action)) {
                String jnum = request.getParameter("jnum");
                String jname = request.getParameter("jname");
                int numworkers = Integer.parseInt(request.getParameter("numworkers"));
                String city = request.getParameter("city");

                String sql = "insert into jobs (jnum, jname, numworkers, city) values (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, jnum);
                pstmt.setString(2, jname);
                pstmt.setInt(3, numworkers);
                pstmt.setString(4, city);

                int rows = pstmt.executeUpdate();
                result = "Job inserted successfully. " + rows + " row(s) affected.";
            }
            else if ("insertShipment".equals(action)) {
                String snum = request.getParameter("shipment_snum");
                String pnum = request.getParameter("shipment_pnum");
                String jnum = request.getParameter("shipment_jnum");
                int quantity = Integer.parseInt(request.getParameter("quantity"));

                String sql = "insert into shipments (snum, pnum, jnum, quantity) values (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, snum);
                pstmt.setString(2, pnum);
                pstmt.setString(3, jnum);
                pstmt.setInt(4, quantity);

                int rows = pstmt.executeUpdate();
                result = "Shipment inserted successfully. " + rows + " row(s) affected.";

                if (quantity >= 100) {
                    PreparedStatement logicStmt = null;
                    try {
                        String logicSql =
                            "update suppliers set status = status + 5 " +
                            "where snum in (select distinct snum from shipments where quantity >= 100)";
                        logicStmt = conn.prepareStatement(logicSql);
                        int logicRows = logicStmt.executeUpdate();

                        result += "<br>Business Logic Detected! Updating Supplier Status.<br>"
                                + "Business Logic updated " + logicRows + " supplier status marks.";
                    } finally {
                        try {
                            if (logicStmt != null) logicStmt.close();
                        } catch (Exception e) {
                            // ignore
                        }
                    }
                } else {
                    result += "<br>Business Logic Not Triggered.";
                }
            }
            else {
                result = "Error: Unknown action.";
            }

        } catch (Exception e) {
            result = "Error: " + e.getMessage();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
            } catch (Exception e) {
                // ignore
            }
            try {
                if (conn != null) conn.close();
            } catch (Exception e) {
                // ignore
            }
        }

        request.setAttribute("result", result);
        request.getRequestDispatcher("dataEntryHome.jsp").forward(request, response);
    }
}