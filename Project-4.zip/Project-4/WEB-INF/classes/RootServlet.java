import java.io.*;
import java.sql.*;
import java.util.Properties;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class RootServlet extends HttpServlet {

    private Properties loadProperties(String fileName, ServletContext context) throws IOException {
        Properties props = new Properties();
        String path = context.getRealPath("/WEB-INF/conf/" + fileName);

        try (FileInputStream fis = new FileInputStream(path)) {
            props.load(fis);
        }

        return props;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String sqlCommand = request.getParameter("sqlCommand");
        StringBuilder result = new StringBuilder();

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Properties props = loadProperties("root.properties", getServletContext());

            conn = DriverManager.getConnection(
                props.getProperty("db.url"),
                props.getProperty("db.username"),
                props.getProperty("db.password")
            );

            stmt = conn.createStatement();

            boolean hasResult = stmt.execute(sqlCommand);

            String lower = sqlCommand.toLowerCase().trim();

            if ((lower.startsWith("insert") || lower.startsWith("update")) && lower.contains("shipments")) {
                Statement logicStmt = conn.createStatement();

                int updatedSuppliers = logicStmt.executeUpdate(
                    "UPDATE suppliers " +
                    "SET status = status + 5 " +
                    "WHERE snum IN (" +
                    "    SELECT snum FROM (" +
                    "        SELECT DISTINCT snum FROM shipments WHERE quantity >= 100" +
                    "    ) AS temp" +
                    ")"
                );

                result.append("<p><b>Business Logic Detected!</b> Updated ")
                      .append(updatedSuppliers)
                      .append(" supplier status values.</p>");

                logicStmt.close();
            }

            if (hasResult) {
                rs = stmt.getResultSet();
                ResultSetMetaData meta = rs.getMetaData();
                int cols = meta.getColumnCount();

                result.append("<table border='1'>");

                result.append("<tr>");
                for (int i = 1; i <= cols; i++) {
                    result.append("<th>").append(meta.getColumnName(i)).append("</th>");
                }
                result.append("</tr>");

                while (rs.next()) {
                    result.append("<tr>");
                    for (int i = 1; i <= cols; i++) {
                        result.append("<td>").append(rs.getString(i)).append("</td>");
                    }
                    result.append("</tr>");
                }

                result.append("</table>");

            } else {
                int count = stmt.getUpdateCount();
                result.append("<p>Command executed successfully. Rows affected: ")
                      .append(count)
                      .append("</p>");
            }

        } catch (Exception e) {
            result.append("<p><b>Error:</b> ").append(e.getMessage()).append("</p>");
        } finally {
            try {
                if (rs != null) rs.close();
            } catch (Exception e) { }
            try {
                if (stmt != null) stmt.close();
            } catch (Exception e) { }
            try {
                if (conn != null) conn.close();
            } catch (Exception e) { }
        }

        request.setAttribute("result", result.toString());
        request.getRequestDispatcher("rootHome.jsp").forward(request, response);
    }
}